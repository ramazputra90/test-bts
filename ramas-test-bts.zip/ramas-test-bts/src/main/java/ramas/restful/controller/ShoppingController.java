package ramas.restful.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import ramas.restful.entity.User;
import ramas.restful.model.*;
import ramas.restful.service.ShoppingService;

import java.util.List;

@RestController
public class ShoppingController {

    @Autowired
    private ShoppingService ShoppingService;

    @PostMapping(
            path = "/api/Shoppings",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public WebResponse<ShoppingResponse> create(User user, @RequestBody CreateShoppingRequest request) {
        ShoppingResponse ShoppingResponse = ShoppingService.create(user, request);
        return WebResponse.<ShoppingResponse>builder().data(ShoppingResponse).build();
    }

    @GetMapping(
            path = "/api/Shoppings/{ShoppingId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public WebResponse<ShoppingResponse> get(User user, @PathVariable("ShoppingId") String ShoppingId) {
        ShoppingResponse ShoppingResponse = ShoppingService.get(user, ShoppingId);
        return WebResponse.<ShoppingResponse>builder().data(ShoppingResponse).build();
    }

    @PutMapping(
            path = "/api/Shoppings/{ShoppingId}",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public WebResponse<ShoppingResponse> update(User user,
                                               @RequestBody UpdateShoppingRequest request,
                                               @PathVariable("ShoppingId") String ShoppingId) {

        request.setId(ShoppingId);

        ShoppingResponse ShoppingResponse = ShoppingService.update(user, request);
        return WebResponse.<ShoppingResponse>builder().data(ShoppingResponse).build();
    }

    @DeleteMapping(
            path = "/api/Shoppings/{ShoppingId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public WebResponse<String> delete(User user, @PathVariable("ShoppingId") String ShoppingId) {
        ShoppingService.delete(user, ShoppingId);
        return WebResponse.<String>builder().data("OK").build();
    }

    @GetMapping(
            path = "/api/Shoppings",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public WebResponse<List<ShoppingResponse>> search(User user,
                                                @RequestParam(value = "createdate", required = false) String createdate,
                                                @RequestParam(value = "name", required = false) String name,
                                                @RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
                                                @RequestParam(value = "size", required = false, defaultValue = "10") Integer size) {
        SearchShoppingRequest request = SearchShoppingRequest.builder()
                .page(page)
                .size(size)
                .createdate(createdate)
                .name(name)
                .build();

        Page<ShoppingResponse> ShoppingResponses = ShoppingService.search(user, request);
        return WebResponse.<List<ShoppingResponse>>builder()
                .data(ShoppingResponses.getContent())
                .paging(PagingResponse.builder()
                        .currentPage(ShoppingResponses.getNumber())
                        .totalPage(ShoppingResponses.getTotalPages())
                        .size(ShoppingResponses.getSize())
                        .build())
                .build();
    }
}
