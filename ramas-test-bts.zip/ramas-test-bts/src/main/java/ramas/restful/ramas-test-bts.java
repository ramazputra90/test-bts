package ramas.restful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ramas-test-btsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ramas-test-btsApplication.class, args);
	}

}
