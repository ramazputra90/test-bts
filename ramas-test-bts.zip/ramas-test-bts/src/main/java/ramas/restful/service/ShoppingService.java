package ramas.restful.service;

import jakarta.persistence.criteria.Predicate;
import ramas.restful.entity.Shopping;
import ramas.restful.entity.User;
import ramas.restful.model.ShoppingResponse;
import ramas.restful.model.CreateShoppingRequest;
import ramas.restful.model.SearchShoppingRequest;
import ramas.restful.model.UpdateShoppingRequest;
import ramas.restful.repository.ShoppingRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ShoppingService {

    @Autowired
    private ShoppingRepository contactRepository;

    @Autowired
    private ValidationService validationService;

    @Transactional
    public ShoppingResponse create(User user, CreateShoppingRequest request) {
        validationService.validate(request);

        Shopping contact = new Shopping();
        contact.setId(UUID.randomUUID().toString());
        contact.setCreatedate(request.getCreatedate());
        contact.setName(request.getName());
        contact.setUser(user);

        contactRepository.save(contact);

        return toShoppingResponse(contact);
    }

    private ShoppingResponse toShoppingResponse(Shopping contact) {
        return ShoppingResponse.builder()
                .id(contact.getId())
                .createdate(contact.getCreatedate())
                .name(contact.getName())
                .build();
    }

    @Transactional(readOnly = true)
    public ShoppingResponse get(User user, String id) {
        Shopping contact = contactRepository.findFirstByUserAndId(user, id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Contact not found"));

        return toShoppingResponse(contact);
    }

    @Transactional
    public ShoppingResponse update(User user, UpdateShoppingRequest request) {
        validationService.validate(request);

        Shopping contact = contactRepository.findFirstByUserAndId(user, request.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Contact not found"));

        contact.setCreatedate(request.getCreatedate());
        contact.setName(request.getName());
        contactRepository.save(contact);

        return toShoppingResponse(contact);
    }

    @Transactional
    public void delete(User user, String contactId) {
        Shopping contact = contactRepository.findFirstByUserAndId(user, contactId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Contact not found"));

        contactRepository.delete(contact);
    }

    @Transactional(readOnly = true)
    public Page<ShoppingResponse> search(User user, SearchShoppingRequest request) {
        Specification<Shopping> specification = (root, query, builder) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(builder.equal(root.get("user"), user));

            if (Objects.nonNull(request.getCreatedate())) {
                predicates.add(builder.like(root.get("createdate"), "%" + request.getCreatedate() + "%"));
            }
            if (Objects.nonNull(request.getName())) {
                predicates.add(builder.like(root.get("name"), "%" + request.getName() + "%"));
            }

            return query.where(predicates.toArray(new Predicate[]{})).getRestriction();
        };

        Pageable pageable = PageRequest.of(request.getPage(), request.getSize());
        Page<Shopping> contacts = contactRepository.findAll(specification, pageable);
        List<ShoppingResponse> contactResponses = contacts.getContent().stream()
                .map(this::toShoppingResponse)
                .toList();

        return new PageImpl<>(contactResponses, pageable, contacts.getTotalElements());
    }
}
