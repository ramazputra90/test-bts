package ramas.restful.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import ramas.restful.entity.Shopping;
import ramas.restful.entity.User;

import java.util.Optional;

@Repository
public interface ShoppingRepository extends JpaRepository<Shopping, String>, JpaSpecificationExecutor<Shopping> {

    Optional<Shopping> findFirstByUserAndId(User user, String id);

}
