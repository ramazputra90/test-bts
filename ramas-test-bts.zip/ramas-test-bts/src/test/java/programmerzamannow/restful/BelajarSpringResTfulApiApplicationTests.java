package programmerzamannow.restful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelajarSpringResTfulApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
