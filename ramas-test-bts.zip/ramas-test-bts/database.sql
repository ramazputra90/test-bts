USE ramas_bts;

CREATE TABLE users
(
    username         VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL,
    password         VARCHAR(100) NOT NULL,
    phone         VARCHAR(100) NOT NULL,
    address             VARCHAR(100) NOT NULL,
    city             VARCHAR(100) NOT NULL,
    country             VARCHAR(100) NOT NULL,
    name             VARCHAR(100) NOT NULL,
    postcode             VARCHAR(100) NOT NULL,
    token            VARCHAR(100),
    token_expired_at BIGINT,
    PRIMARY KEY (username),
    UNIQUE (token)
) ENGINE InnoDB;

SELECT *
FROM users;

DESC users;

CREATE TABLE shopping
(
    id         VARCHAR(100) NOT NULL,
    createdate   VARCHAR(100) NOT NULL,
    name  VARCHAR(100),
    PRIMARY KEY (id),
    FOREIGN KEY fk_users_shopping (name) REFERENCES users (username)
) ENGINE InnoDB;

SELECT *
FROM shopping;

DESC shopping;

DELETE FROM shopping;

DELETE FROM users;

